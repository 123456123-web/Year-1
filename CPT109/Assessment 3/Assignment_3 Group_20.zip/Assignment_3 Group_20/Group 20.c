/* 
Name: Bank Information System
File Name:Group20.c
Copyright: Free 
Author: Group 20
Overall description:
Your team is employed by a bank to implement a system to manage the banking affairs.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>

#define MAXUSER        100    /*Maximum user accounts*/
#define MAXACCOUNT    5    /*Maximum account number*/

/*For storing account information*/
typedef struct
{
    char accID[17];                /*Sign of the account*/
    double balance;
}Account;

/*For storing account information*/
typedef struct
{
    char username[32];
    char address[128];
    char phonenumber[12];
    char PIN[7];
    char IDnum[19];                /*Personal identification number*/
    int acc_count;                /*Account number*/
    Account acc[MAXACCOUNT];    /*Account information*/
}Customer;

/*Use time to sign the account*/
void getAccID(char id[17])
{
    time_t  t;
    char s[5];
    struct tm *tmp;
    t = time(NULL);
    tmp = localtime(&t);

    /*Write the information to a string and save it in file*/
    sprintf(s, "%d", tmp->tm_year + 1900);
    strcat(id, s);

    sprintf(s, "%d", tmp->tm_mon);
    strcat(id, s);

    sprintf(s, "%d", tmp->tm_mon);
    strcat(id, s);

    sprintf(s, "%d", tmp->tm_hour);
    strcat(id, s);

    sprintf(s, "%d", tmp->tm_min);
    strcat(id, s);

    sprintf(s, "%d", tmp->tm_sec);
    strcat(id, s);
}

/*Functions for reading the file where customer information is stored*/
int Readfile(Customer cus[])
{
    FILE *fp;
    int totalnum = 0, i, j;
    
    fp = fopen("customer.txt", "r");
    if (!fp)return 0;
    fscanf(fp, "%d", &totalnum);
    
    for (i = 0; i < totalnum; i++)
    {
        fscanf(fp, "%s %s %s %s %s %d", cus[i].username, cus[i].address, cus[i].phonenumber, cus[i].PIN, cus[i].IDnum, &cus[i].acc_count);
        for (j = 0; j < cus[i].acc_count; j++)
        {
            fscanf(fp, "%s %lf", &cus[i].acc[j].accID, &cus[i].acc[j].balance);
        }
    }
    fclose(fp);

    return totalnum;
}

/*Write the information to a string and save it in file*/
void Writefile(const Customer cus[], int nlen)
{
    FILE *fp;
    int i, j;

    fp = fopen("customer.txt", "w");
    fprintf(fp, "%d\n\n", nlen);

    for (i = 0; i < nlen; i++)
    {
        fprintf(fp, "%s %s %s %s %s \n%d\n", cus[i].username, cus[i].address, cus[i].phonenumber, cus[i].PIN, cus[i].IDnum, cus[i].acc_count);
        for (j = 0; j < cus[i].acc_count; j++)
        {
            fprintf(fp, "%s %lf\n", cus[i].acc[j].accID, cus[i].acc[j].balance);
        }
        fprintf(fp, "\n");
    }

    fclose(fp);
}

/*Functions for retrieving saved IDs*/
int FindID(const Customer cus[], char id[18], int nlen)
{
    int i;
    for (i = 0; i < nlen; i++)
    {
        if (strcmp(cus[i].IDnum, id) == 0)
        {
            return i;
        }
    }
    return -1;
}

/*Function to check whether the input is numbers*/
int CheckDigit(char phone[],int len)
{
    int i;
    for (i = 0; i< len; i++)
    {
            if (!isdigit(phone[i])) return 0;
            
    }
    return 1;
}

/*Functions for checking the length of input characters*/
int CheckLength(char number[],int len)
{
    int length = 0;
    length = strlen(number);
    

   while(length>len)
    {
        fflush(stdin);
        return 0;
    }
    return 1;
}

/*Functions for the new user registration process*/
void Regis(Customer cus[], int *nlen)
{
    char uname[32], address[128], phonenumber[12], pin[7], id[19],c;

    printf("please input your name:");while ((c = getchar()) != EOF && c != '\n'); scanf("%31[^\n]", uname);
    strcpy(cus[*nlen].username, uname);
    printf("please input your address:");scanf("%s", address);
    strcpy(cus[*nlen].address, address);
    printf("please input your phonenumber(11 length number):");scanf("%s", phonenumber);
    while (!CheckDigit(phonenumber,11)||!CheckLength(phonenumber,11))
    {
        fflush(stdin);
        printf("input invalid!!!\nplease input your phonenumber(11 length number):");
        scanf("%s", phonenumber);
    }
    strcpy(cus[*nlen].phonenumber, phonenumber);
    printf("please input your PIN number(6 length number):"); scanf("%s", pin);
    while (!CheckDigit(pin, 6)||!CheckLength(pin,6))
    {
        fflush(stdin);
        printf("input invalid!!!\nplease input your PIN number(6 length number):");
        scanf("%s", pin);
    }
    strcpy(cus[*nlen].PIN, pin);
    printf("please input your ID number(18 length number):"); scanf("%s", id);
    while (!CheckDigit(id, 18)||FindID(cus,id,*nlen)!=-1||!CheckLength(id,18))
    {
        fflush(stdin);
        printf("input invalid or ID has exsited!!!\nplease input your ID number(18 length number):");
        scanf("%s", id);
    }
    strcpy(cus[*nlen].IDnum, id);

    cus[*nlen].acc_count = 0;
    (*nlen)++;

    printf("regis success!\n");
    system("pause");
    system("cls");
}

/*Functions for the user login process*/
int Login(const Customer cus[], int nlen)
{
    int npos;
    char uid[19];

    printf("please input your IDnum(18 length number):");
    scanf("%s", uid);

    npos = FindID(cus, uid, nlen);
    if (npos == -1)
    {
        printf("user ID not exist!\n\n");
        system("pause");
        system("cls");
        return -1;
    }

    return npos;
}

/*Functions for balance enquiries*/
void BalanceInquiry(Customer cus)
{
    int i, nchocie = -1;
    
    if (cus.acc_count == 0)
    {
        printf("No account in your name\n"); return;
    }

    printf("\nYou have the following account:\n\n");
    printf("Index\t\t\tAccountID\n");
    for (i = 0; i < cus.acc_count;i++)
    {
        printf("%d\t\t\t%s\n", i + 1, cus.acc[i].accID);
    }
    printf("\nplease select your choice(press 0 to see your all account!):");

    while (scanf("%d", &nchocie)!=1||nchocie>cus.acc_count || nchocie < 0)
    {
        fflush(stdin);
        printf("input invalid!\nplease select your choice(press 0 to see your all account!):");
    }

    
    if (nchocie == 0)
    {
        system("cls");
        printf("Index\t\t\tAccountID\t\t\tBalance\n");
        for (i = 0; i < cus.acc_count; i++)
        {
            printf("%d\t\t\t%s\t\t\t%.2lf\n", i + 1, cus.acc[i].accID, cus.acc[i].balance);
        }
        printf("\n");
        return;
    }

    
    system("cls");
    printf("AccountID\t\t\tBalance\n");
    printf("%s\t\t\t%.2lf\n\n", cus.acc[i-1].accID, cus.acc[i-1].balance);
}

/*Functions for Withdraw*/
void Withdraw(Customer *cus)
{
    int i, nchocie = -1;
    double money;
    
    if ((*cus).acc_count == 0)
    {
        printf("No account in your name\n"); return;
    }

    printf("\nYou have the following account:\n\n");
    printf("Index\t\t\tAccountID\t\t\tBalance\n");
    printf("-----------------------------------\n");
    for (i = 0; i < (*cus).acc_count; i++)
    {
        printf("%d\t\t\t%s\t\t\t%lf\n", i + 1, (*cus).acc[i].accID, (*cus).acc[i].balance);
    }
    printf("\nplease select your account:");

    while ( scanf("%d", &nchocie)!=1||nchocie>(*cus).acc_count || nchocie < 0)
    {
        fflush(stdin);
        printf("input invalid!\nplease select your account:");
    }

    printf("\nplease input your withdraw account:"); scanf("%lf", &money);
    if ((*cus).acc[nchocie - 1].balance < money)printf("Insufficient funds!\n\n");
    else
    {
        (*cus).acc[nchocie - 1].balance -= money;
        printf("withdraw success!your current balance is :%lf\n\n", (*cus).acc[nchocie - 1].balance);
    }
}

/*Functions for user Deposits*/
void Deposits(Customer *cus)
{
    int i, nchocie = -1;
    double money;
    
    if ((*cus).acc_count == 0)
    {
        printf("No account in your name\n");
        return;
    }

    printf("\nYou have the following account:\n");
    printf("Index\t\t\tAccountID\t\t\ttBalance\n");
    for (i = 0; i < (*cus).acc_count; i++)
    {
        printf("%d\t\t\t%s\t\t\t%lf\n", i + 1, (*cus).acc[i].accID, (*cus).acc[i].balance);
    }
    printf("\nplease select your account:");

    while (scanf("%d", &nchocie)!=1||nchocie>(*cus).acc_count || nchocie < 0)
    {
        fflush(stdin);
        printf("input invalid!\nplease select your account:");
    }

    printf("please input your deposit account:");
    while (scanf("%lf", &money)!=1||money<0)
    {
        fflush(stdin);
        printf("input should be a postive number!\nplease input your deposit account:");
    }

    (*cus).acc[nchocie - 1].balance += money;
    printf("deposits success!your current balance is %lf:\n\n", (*cus).acc[nchocie - 1].balance);
}

/*Functions for calculating user accounts*/
int CountAccount(const Customer cus[], int nlen)
{
    int i, total = 0;
    for (i = 0; i < nlen; i++)
    {
        total += cus[i].acc_count;
    }
    return total;
}

/*Functions for adding accounts for users*/
void AddAccount(Customer *cus)
{
    char id[17];
    memset(id, 0, 17);
    if ((*cus).acc_count >= MAXACCOUNT)
    {
        printf("account has full!\n\n");
        return;
    }
    getAccID(id);
    strcpy((*cus).acc[(*cus).acc_count].accID, id);
    (*cus).acc_count++;
    printf("account add success!\n\n");
}

/*Functions for removing user accounts*/
void RemoveAccount(Customer *cus)
{
    int i, nchocie = -1;
    if ((*cus).acc_count <=0)
    {
        printf("account is empty!\n\n");
        return;
    }

    
    printf("\nYou have the following account:\n");
    printf("Index\t\t\tAccountID\t\t\ttBalance\n");
    for (i = 0; i < (*cus).acc_count; i++)
    {
        printf("%d\t\t\t%s\t\t\t%lf\n", i + 1, (*cus).acc[i].accID, (*cus).acc[i].balance);
    }
    printf("\nplease select your account:");

    while (scanf("%d", &nchocie)!=1||nchocie>(*cus).acc_count || nchocie < 0)
    {
        fflush(stdin);
        printf("input invalid!\nplease select your account:");
    }
    
    for (i = nchocie - 1; i < (*cus).acc_count - 1; i++)
    {
        memcpy(&(*cus).acc[i], &(*cus).acc[i + 1], sizeof(Account));
    }
    (*cus).acc_count--;
    printf("account remove success!\n\n");
}

/*Functions used to edit account for the user*/
void EditAccount(Customer *cus)
{
    int i, nchocie = -1;
    char id[17];
    memset(id, 0, 17);
    if ((*cus).acc_count <= 0)
    {
        printf("account is empty!\n\n");
        return;
    }

    
    printf("\nYou have the following account:\n");
    printf("Index\t\t\tAccountID\t\t\tBalance\n");
    for (i = 0; i < (*cus).acc_count; i++)
    {
        printf("%d\t\t\t%s\t\t\t%lf\n", i + 1, (*cus).acc[i].accID, (*cus).acc[i].balance);
    }
    printf("\nplease select your account:"); /*scanf("%d", &nchocie);*/

    while (scanf("%d", &nchocie)!=1||nchocie>(*cus).acc_count || nchocie < 0)
    {
        fflush(stdin);
        printf("input invalid!!please select your account:");
        
    }

    getAccID(id);
    strcpy((*cus).acc[(*cus).acc_count].accID, id);
    printf("account ID modify success!\n\n");
}

/*User menu, displayed after user login*/
void CustomerMenu(Customer *cus)
{
    int nchocie;
    char pin[7];
    while (1)
    {
        fflush(stdin);
        system("cls");
        printf("1.Display balance\t\t2.Withdraw\t\t3.Return\n\n");
        printf("please input your choice:");
        while (scanf("%d", &nchocie)!=1||(nchocie > 3 || nchocie < 1))
        {
            fflush(stdin);
            printf("Input invalid, try again\n\n");
            printf("1.Display balance\t\t2.Withdraw\t\t3.Return\n\n");
            printf("please input your choice:");
        }

        if (nchocie == 3)break;

        printf("please input your PIN code:"); scanf("%s", pin);
        if (strcmp((*cus).PIN,pin)!=0)
        {
            printf("PIN not correct!please check\n\n");
            system("pause");
            continue;
        }

        if (nchocie == 1)
            BalanceInquiry(*cus);
        else if (nchocie == 2)
            Withdraw(cus);

        system("pause");
    }
}

/*Bank staff menu*/
void BankclerkMenu(Customer cus[], int nlen)
{
    int i, nchocie1, nchocie2;

    printf("All customer information as below:\n");
    printf("index\t\tusername\taddress\t\tphonenumber\t\tIDnum\t\t\taccountcount\n");
    for (i = 0; i < nlen; i++)
    {
        printf("%d\t\t%s\t\t%s\t\t%s\t\t%s\t\t\t%d\n", i + 1, cus[i].username, cus[i].address, cus[i].phonenumber, cus[i].IDnum, cus[i].acc_count);
    }
    printf("\n");
    printf("please input your choice, or press any character to exit:");
    scanf("%d", &nchocie1);
    if (nchocie1<1||nchocie1>nlen)
    {
        printf("input invalid\n\n");
        while (getchar() != '\n'){
            getchar();
            break;
        }
        system("pause");
        system("cls");
        return;
    }
    nchocie1--;

    while (1)
    {
        fflush(stdin);
        system("cls");
        printf("1.Add account\t\t2.Remove account\t\t3.Edit account\t\t4.Deposit\t\t5.Return\n\n");
        printf("please input your choice:");
        while (scanf("%d", &nchocie2)!=1||(nchocie2!=1&&nchocie2!=2&&nchocie2!=3&&nchocie2!=4&&nchocie2!=5))
        {
            fflush(stdin);
            printf("Incorrect input, try again\n\n");
            while (getchar() != '\n'){
                getchar();
                printf("1.Add account\t\t2.Remove account\t\t3.Edit account\t\t4.Deposit\t\t5.Return\n\n");
                printf("please input your role choice:\n");
                break;
            }
        }

        if (nchocie2 == 1)
            AddAccount(&cus[nchocie1]);
        else if (nchocie2 == 2)
            RemoveAccount(&cus[nchocie1]);
        else if (nchocie2 == 3)
            EditAccount(&cus[nchocie1]);
        else if (nchocie2 == 4)
            Deposits(&cus[nchocie1]);
        else if (nchocie2 == 5)
        break;
        system("pause");
    }
}

/*Bank Manager Menu*/
void ManagerMenu(Customer cus[], int nlen)
{
    int nchocie;

    while (1)
    {
        fflush(stdin);
        system("cls");
        printf("1.Count customers number\t\t2.Count accounts number\t\t3.Return\n\n");
        printf("please input your choice:");
        while (scanf("%d", &nchocie)!=1||(nchocie!=1&&nchocie!=2&&nchocie!=3))
        {
            fflush(stdin);
            printf("\nIncorrect input, try again\n\n");
            while (getchar() != '\n'){
                getchar();
                printf("1.Count customers number\t\t2.Count accounts number\t\t3.Return\n\n");
                printf("please input your role choice:\n");
                break;
            }
        }

        if (nchocie > 3 || nchocie < 1)
        {
            printf("input invalid\n\n");
            continue;
        }

        if (nchocie == 1)
            printf("customers number is:%d\n\n", nlen);
        else if (nchocie == 2)
            printf("accounts number is:%d\n\n", CountAccount(cus, nlen));
        else if (nchocie == 3)
            break;
        system("pause");
    }
}

/*Main program*/
int main()
{
    Customer customer[MAXUSER];
    int totalcus, curcus, nchocie = 0;
    char nchocie0, ch;
    char clerkpwd[32], managepwd[32];
    memset(customer, 0, sizeof(Customer)*MAXUSER);
    totalcus = Readfile(customer);

    while (1)
    {
        
        system("cls");
        printf("1.Customer\t\t2.Bank clerk\t\t3.Manager\t\t4.Exit\n\n");
        printf("please input your role choice:\n");
        fflush(stdin);
        
        scanf("%c", &nchocie0);
            while (nchocie0 != '1' && nchocie0 != '2' && nchocie0 != '3' && nchocie0 != '4')
        {
            while (getchar() == '\n'){
                printf("\nWrong input, please try again\n");
                system("pause");
                system("cls");
                printf("1.Customer\t\t2.Bank clerk\t\t3.Manager\t\t4.Exit\n\n");
                printf("please input your role choice:\n");
                scanf("%c", &nchocie0);
                break;
            }
        }

        if (nchocie0 == '1')
        {
            system("cls");
            printf("1.Login\t\t2.Regis\n\n");
            printf("please input your choice:");
            while (scanf("%d",&nchocie)!=1 || (nchocie<1||nchocie>2))
            {
                fflush(stdin);
                printf("Incorrect input, please try again\n");
                while (getchar() != '\n'){
                    getchar();
                    printf("1.Login\t\t2.Regis\n\n");
                    printf("please input your choice:");
                    break;
                }
            }
            if (nchocie == 1)
            {
                curcus = Login(customer, totalcus);
                while((ch = getchar()) != '\n' && ch != EOF);
                if (curcus != -1)
                {
                    system("cls");
                    CustomerMenu(&customer[curcus]);
                    while((ch = getchar()) != '\n' && ch != EOF);
                }
            }
            else if (nchocie== 2)
            {
                Regis(customer, &totalcus);
                while((ch = getchar()) != '\n' && ch != EOF);
            }
            else
            {
                system("pause");
                printf("input invalid\n\n");
            }
        }
        else if (nchocie0 == '2')
        {
            system("cls");
            printf("please input password:"); scanf("%s", clerkpwd);
            while (strcmp(clerkpwd,"Mark123456")!=0)
            {
                printf("password incorrect!\nplease input password again:"); scanf("%s", clerkpwd);
            }
            BankclerkMenu(customer, totalcus);
            while((ch = getchar()) != '\n' && ch != EOF);
        }
        else if (nchocie0 == '3')
        {
            system("cls");
            printf("please input password:"); scanf("%s", managepwd);
            while (strcmp(managepwd, "Leach123456") != 0)
            {
                printf("password incorrect!\nplease input password again:"); scanf("%s", managepwd);
            }
            ManagerMenu(customer, totalcus);
            while((ch = getchar()) != '\n' && ch != EOF);
        }
        else if (nchocie0 == '4')
        {
            break;
        }
    }

    Writefile(customer, totalcus);
    system("pause");
    return 0;
}

